﻿using NUnit.Framework;
using System.Collections;

namespace NUnit.LibaryTest_RichkovDmitry
{
    class CircleFactory
    {
        public static IEnumerable CircleCases
        {
            get
            {
                for (int i = 1; i <= 1001; i += 200)
                    yield return new TestCaseData(i);
            }
        }
    }
}
