﻿using NUnit.Framework;
using System.Collections;

namespace NUnit.LibaryTest_RichkovDmitry
{
    class TriangleFactory
    {
        public static IEnumerable TriangleCases
        {
            get
            {
                for (int x = 0; x <= 10000; x += 2000)
                    for (int y = 0; y <= 10000; y += 2000)
                        for (int z = 0; z <= 10000; z += 2000)
                            yield return new TestCaseData(x, y, z);
            }
        }
    }
}
