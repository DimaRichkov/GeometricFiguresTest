﻿using NUnit.Framework;
using System.Collections;

namespace NUnit.LibaryTest_RichkovDmitry
{
    class SquareFactory
    {
        public static IEnumerable SquareCases
        {
            get
            {
                for (int i = 0; i <= 10000; i += 2000)
                    yield return new TestCaseData(i);
            }
        }
    }
}
