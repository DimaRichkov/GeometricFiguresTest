﻿using GeometricFigures;
using NUnit.Framework;
using System;

namespace NUnit.LibaryTest_RichkovDmitry
{
    [TestFixture]
    public class TestClass
    {
        [Test, TestCaseSource(typeof(CircleFactory), "CircleCases")]
        public void CircleRadius(int radius)
        {
            Circle c = new Circle(radius);
            Assert.AreEqual(2.0 * Math.PI * radius, c.getLengthCircle());
        }

        [Test, TestCaseSource(typeof(CircleFactory), "CircleCases")]
        public void CircleArea(int radius)
        {
            Circle c = new Circle(radius);
            Assert.AreEqual(Math.PI * radius * radius, c.getAreaCircle());
        }

        [Test, TestCaseSource(typeof(SquareFactory), "SquareCases")]
        public void SquareLength(int side)
        {
            Square s = new Square(side);
            Assert.IsTrue(4 * side == s.getLengthSquare());
        }

        [Test, TestCaseSource(typeof(SquareFactory), "SquareCases")]
        public void SquareArea(int side)
        {
            Square s = new Square(side);
            Assert.IsTrue((side * side) == s.getAreaSquare());
        }

        [Test, TestCaseSource(typeof(TriangleFactory), "TriangleCases")]
        public void TriangleLength(int x, int y, int z)
        {
            if ((x + y < z) || (x + z) < y || (y + z < x))
                return;

            Triangle t = new Triangle(x, y, z);
            Assert.IsTrue((x + y + z) == t.getLengthTriangle());
        }

        [Test, TestCaseSource(typeof(TriangleFactory), "TriangleCases")]
        public void TriangleArea(int x, int y, int z)
        {
            if ((x + y < z) || (x + z) < y || (y + z < x))
                return;

            int p = (x + y + z) / 2;
            Double S = Math.Sqrt(p * (p - x) * (p - y) * (p - z));
            Triangle t = new Triangle(x, y, z);
            Assert.IsTrue(S == t.getAreaTriangle());
        }

        [Test]
        [TestCase(0)]
        [TestCase(-10)]
        public void TestSquareConstructor(int side)
        {
            Assert.Throws(typeof(ArgumentException), () => { new Square(side); });
        }

        [Test]
        [TestCase(0, 0, 0)]
        [TestCase(-10, -20, -30)]
        public void TestTriangleConstructor(int x, int y, int z)
        {
            Assert.Throws(typeof(ArgumentException), () => { new Triangle(x, y, z); });
        }
    }
}
