﻿using GeometricFigures;
using NUnit.Framework;
using System;

namespace NUnit.LibaryTest_RichkovDmitry
{
    [TestFixture]
    public class Random
    {
        [Test]
        public void RandomCircleLength([Random(1, 1000000, 5)] int radius)
        {
            Circle c = new Circle(radius);
            Assert.AreEqual(2.0 * Math.PI * radius, c.getLengthCircle());
        }

        [Test]
        public void RandomCircleArea([Random(1, 1000000, 5)] int radius)
        {
            Circle c = new Circle(radius);
            Assert.AreEqual(Math.PI * radius * radius, c.getAreaCircle());
        }


        [Test]
        public void RandomSquareLength([Random(1, 1000000, 5)] int side)
        {
            Square s = new Square(side);
            Assert.IsTrue(4 * side == s.getLengthSquare());
        }

        [Test]
        public void RandomSquareArea([Random(1, 1000000, 5)] int side)
        {
            Square s = new Square(side);
            Assert.IsTrue((side * side) == s.getAreaSquare());
        }

        [Test]
        public void RandomTriangleLength([Random(1, 1000000, 5)] int x,
                                       [Random(1, 1000000, 5)] int y,
                                       [Random(1, 1000000, 5)] int z)
        {
            if ((x + y < z) || (x + z) < y || (y + z < x))
                return;

            Triangle t = new Triangle(x, y, z);
            Assert.IsTrue((x + y + z) == t.getLengthTriangle());
        }

        [Test]
        public void RandomTriangleArea([Random(1, 1000000, 5)] int x,
                                       [Random(1, 1000000, 5)] int y,
                                       [Random(1, 1000000, 5)] int z)
        {
            if ((x + y < z) || (x + z) < y || (y + z < x))
                return;

            int p = (x + y + z) / 2;
            Console.WriteLine("p = " + p);
            double S = Math.Sqrt(p * (p - x) * (p - y) * (p - z));
            Triangle t = new Triangle(x, y, z);
            Assert.IsTrue(S == t.getAreaTriangle());
        }
    }
}
